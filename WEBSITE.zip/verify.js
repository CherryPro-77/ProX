const admin = require('firebase-admin');

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    }),
    databaseURL: "https://prox-cf201-default-rtdb.firebaseio.com"
  });
}

exports.handler = async function(event, context) {
  const userKey = event.queryStringParameters.key;

  if (!userKey) {
    return {
      statusCode: 400,
      body: JSON.stringify({ success: false, message: "No key provided." })
    };
  }

  try {
    const db = admin.database();
    const ref = db.ref('license_keys/' + userKey);
    const snapshot = await ref.once('value');
    const keyData = snapshot.val();

    if (keyData && keyData.status === "active") {
      return {
        statusCode: 200,
        body: JSON.stringify({ success: true, message: "Login successful!" })
      };
    } else {
      return {
        statusCode: 401,
        body: JSON.stringify({ success: false, message: "Invalid or expired key." })
      };
    }
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
};