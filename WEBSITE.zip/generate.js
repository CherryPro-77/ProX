const admin = require('firebase-admin');

// Initialize Firebase securely using Environment Variables
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    }),
    databaseURL: "https://prox-cf201-default-rtdb.firebaseio.com"
  });
}

exports.handler = async function(event, context) {
  // Only allow POST requests for generating keys
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    // Generate a random ProX key
    const newKey = 'PROX-' + Math.random().toString(36).substr(2, 9).toUpperCase();
    const db = admin.database();
    const ref = db.ref('license_keys/' + newKey);

    // Save to Realtime Database
    await ref.set({
      status: "active",
      created_at: new Date().toISOString()
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ success: true, key: newKey })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
};